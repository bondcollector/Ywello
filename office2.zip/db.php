<?php
	$db_name="ato";
	$db_username="root";
	$db_pass="";
	$db_host="localhost";
	$conn = mysqli_connect($db_host,$db_username,$db_pass,$db_name);
	if ($conn) {
		// echo "conn";
	}else{
		die(mysqli_error($conn));
	}
?>

