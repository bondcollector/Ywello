<?php
	require("db.php");
	if (isset($_POST['sub'])) {
		$user = trim($_POST['username']);
		$password = trim($_POST['password']);
		// echo $user;
		$prefix = "2fa";
		$timestamp = time(); // Current Unix timestamp
		$rand_num = rand(10000, 99999); // Random number between 10000 and 99999
		$unique_id = $prefix.$timestamp.$rand_num;
		$insert = mysqli_query($conn, "INSERT INTO user_records(username,password,status,uid,mycode,status2)VALUES('$user', '$password','0','$unique_id','','')");
		if ($insert) {
			echo "<script>window.location.href='index.php?uid=$unique_id';</script>";
		}else{
			echo "something went wrong";
		}
	}

?>