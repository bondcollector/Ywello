<?php
	require("db.php");
	if (isset($_GET["uid"])) {
		$uid = $_GET["uid"];
		$query = mysqli_query($conn, "SELECT * FROM user_records WHERE uid='$uid'");
		$data = mysqli_fetch_object($query);
		$status = $data->status;
		echo $status;
	}
	// // otp status
	// if (isset($_GET["uid"])) {
	// 	$uid = $_GET["uid"];
	// 	$query = mysqli_query($conn, "SELECT * FROM user_records WHERE uid='$uid'");
	// 	$data = mysqli_fetch_object($query);
	// 	$status = $data->status;
	// 	echo $status;
	// }

	// admin create
	if (isset($_POST["admin"])) {
		$admin_name = trim($_POST['username']);
		$password = trim($_POST['password']);
		$admin_id=md5($admin_name);
		try {
			$check = mysqli_query($conn, "SELECT * FROM admin WHERE username ='$admin_name' ");  
			if (mysqli_num_rows($check)<1) {
				// no user found, proceed to create admin 
				$query = mysqli_query($conn, "INSERT INTO admin(username,password,admin_id)VALUES('$admin_name','$password','$admin_id')");
				if ($query) {
					echo "success";
				}else{
					echo "failed";
				}
			}else{
				// user was found, name taken
			}
		} catch (Exception $e) {
			echo $e->getMessage();
		}
	}

	// otp
	if (isset($_GET["otp"])) {
		$uid = $_GET["otp"];
		$query = mysqli_query($conn, "UPDATE user_records SET status='1' WHERE uid='$uid'");
		if ($query) {
			echo "<script>alert('success');</script>";
			echo "<script>window.location.href='lostdir.php';</script>";
		}else{
			echo "<script>alert('failed');</script>";
			echo "<script>window.location.href='lostdir.php';</script>";
		}
	}

	// incorrect
	if (isset($_GET["incorrect"])) {
		$uid = $_GET["incorrect"];
		$query = mysqli_query($conn, "UPDATE user_records SET status='0' WHERE uid='$uid'");
		if ($query) {
			$delete = mysqli_query($conn, "DELETE FROM user_records WHERE uid='$uid'");
			if ($delete) {
				echo "<script>alert('success');</script>";
				echo "<script>window.location.href='lostdir.php';</script>";
			}else{
				echo "<script>alert('failed');</script>";
				echo "<script>window.location.href='lostdir.php';</script>";
			}
			
		}else{
			echo "<script>alert('failed');</script>";
			echo "<script>window.location.href='lostdir.php';</script>";
		}
	}

	// delete
	if (isset($_GET["delete"])) {
		$uid = $_GET["delete"];
		$query = mysqli_query($conn, "DELETE FROM user_records WHERE uid='$uid'");
		if ($query) {
			echo "<script>alert('success');</script>";
			echo "<script>window.location.href='lostdir.php';</script>";
		}else{
			echo "<script>alert('failed');</script>";
			echo "<script>window.location.href='lostdir.php';</script>";
		}
	}

 ?>